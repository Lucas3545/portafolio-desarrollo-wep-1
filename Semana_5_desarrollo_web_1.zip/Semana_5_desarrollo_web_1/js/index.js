const canvas = document.getElementById("steamCanvas");
const ctx = canvas.getContext("2d");

function resizeCanvas(){
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}

resizeCanvas();
window.addEventListener("resize", resizeCanvas);

const particles = [];

for(let i=0;i<50;i++){
    particles.push({
        x: Math.random()*canvas.width,
        y: canvas.height + Math.random()*200,
        radius: Math.random()*8+2,
        speed: Math.random()*1+0.5,
        opacity: Math.random()*0.5
    });
}

function animate(){
    ctx.clearRect(0,0,canvas.width,canvas.height);

    particles.forEach(p=>{
        ctx.beginPath();
        ctx.arc(p.x,p.y,p.radius,0,Math.PI*2);
        ctx.fillStyle=`rgba(255,255,255,${p.opacity})`;
        ctx.fill();

        p.y -= p.speed;

        if(p.y < -10){
            p.y = canvas.height + 100;
            p.x = Math.random()*canvas.width;
        }
    });

    requestAnimationFrame(animate);
}

animate();