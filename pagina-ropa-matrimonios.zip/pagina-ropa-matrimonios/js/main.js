const navbar = document.querySelector('.navbar');
const menu = document.getElementById('menu');

document.querySelectorAll('a[href^="#"]').forEach(link => {

    link.addEventListener('click', function(e){

        e.preventDefault();

        document
            .querySelector(this.getAttribute('href'))
            .scrollIntoView({
                behavior:'smooth'
            });

        // Cierra el menú en móvil después de elegir una opción
        if(menu.classList.contains('show')){
            bootstrap.Collapse.getOrCreateInstance(menu).hide();
        }

    });

});

// Fondo oscuro en la barra de navegación al hacer scroll
window.addEventListener('scroll', () => {
    navbar.classList.toggle('scrolled', window.scrollY > 50);
});

console.log("Regina Preciado Bridal Styling");
