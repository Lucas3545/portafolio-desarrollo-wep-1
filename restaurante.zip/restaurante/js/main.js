console.log("Bienvenido a El Club Gourmet");

// Scroll suave
document.querySelectorAll('a[href^="#"]').forEach(enlace => {

    enlace.addEventListener("click", function(e) {

        e.preventDefault();

        const destino = document.querySelector(
            this.getAttribute("href")
        );
//el .scrollIntoView() permite que el elemento destino se desplace suavemente a la vista del usuario.
        destino.scrollIntoView({
            behavior: "smooth"
        });

    });

});