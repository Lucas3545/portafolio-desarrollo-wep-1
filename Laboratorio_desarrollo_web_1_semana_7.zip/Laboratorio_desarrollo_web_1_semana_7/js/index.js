const formulario = document.getElementById("formulario-contacto");
const todosLosCampos = formulario.querySelectorAll("input, select, textarea");
const botonEnviar = formulario.querySelector('button[type="submit"]');
const botonLimpiar = formulario.querySelector('button[type="reset"]');
let enviando = false;

// Solo cuentan los campos activos (Dirección está deshabilitada mientras está oculta)
function camposActivos() {
  return Array.from(todosLosCampos).filter(function (campo) {
    return !campo.disabled;
  });
}

// Este es el canvas que muestra el estado del formulario (neutro, error o éxito)
const canvasEstado = document.getElementById("canvas-estado");
const ctxEstado = canvasEstado.getContext("2d");
const mensajeEstado = document.getElementById("mensaje-estado");
let estadoActual = "neutro"; // "neutro", "error" o "exito"

// Lee los colores de las variables CSS para que el canvas combine con la página
function colorCSS(nombre) {
  return getComputedStyle(document.documentElement).getPropertyValue(nombre).trim();
}

function contarValidos() {
  return camposActivos().filter(function (campo) {
    return campo.validity.valid;
  }).length;
}

function dibujarEstado(tipo) {
  const ancho = canvasEstado.width;
  const alto = canvasEstado.height;
  const total = camposActivos().length;
  const validos = contarValidos();
  const colores = {
    neutro: colorCSS("--color-primario"),
    error: colorCSS("--color-error"),
    exito: colorCSS("--color-exito"),
  };
  const color = colores[tipo];

  ctxEstado.clearRect(0, 0, ancho, alto);

  // Ícono: triángulo para error, círculo para neutro y éxito (con sombra)
  ctxEstado.save();
  ctxEstado.fillStyle = color;
  ctxEstado.shadowColor = "rgba(0, 0, 0, 0.3)";
  ctxEstado.shadowBlur = 4;
  ctxEstado.shadowOffsetY = 2;
  ctxEstado.beginPath();
  if (tipo === "error") {
    ctxEstado.moveTo(35, 8);
    ctxEstado.lineTo(62, 58);
    ctxEstado.lineTo(8, 58);
    ctxEstado.closePath();
  } else {
    ctxEstado.arc(35, 35, 25, 0, Math.PI * 2);
  }
  ctxEstado.fill();
  ctxEstado.restore();

  // Símbolo blanco dentro del ícono
  ctxEstado.save();
  ctxEstado.fillStyle = "#ffffff";
  ctxEstado.strokeStyle = "#ffffff";
  ctxEstado.textAlign = "center";
  if (tipo === "exito") {
    ctxEstado.lineWidth = 5;
    ctxEstado.lineCap = "round";
    ctxEstado.beginPath();
    ctxEstado.moveTo(23, 36);
    ctxEstado.lineTo(32, 45);
    ctxEstado.lineTo(48, 26);
    ctxEstado.stroke();
  } else if (tipo === "error") {
    ctxEstado.font = "bold 26px Arial";
    ctxEstado.fillText("!", 35, 52);
  } else {
    ctxEstado.font = "bold 26px Georgia";
    ctxEstado.fillText("i", 35, 44);
  }
  ctxEstado.restore();

  // Barra de progreso: cuántos campos están correctos
  const barraX = 80;
  const barraY = 38;
  const barraAncho = ancho - barraX - 10;
  const barraAlto = 12;

  ctxEstado.fillStyle = colorCSS("--color-borde");
  ctxEstado.fillRect(barraX, barraY, barraAncho, barraAlto);

  ctxEstado.fillStyle = color;
  ctxEstado.fillRect(barraX, barraY, barraAncho * (validos / total), barraAlto);

  ctxEstado.fillStyle = colorCSS("--color-texto");
  ctxEstado.font = "14px Arial";
  ctxEstado.textAlign = "left";
  ctxEstado.fillText(validos + " de " + total + " campos correctos", barraX, barraY - 10);
}

// Actualiza el dibujo y el texto (el texto es lo que leen los lectores de pantalla)
function actualizarEstado(tipo) {
  const pendientes = camposActivos().length - contarValidos();
  let texto;

  if (tipo === "exito") {
    texto = "¡Gracias! Recibimos su mensaje y le responderemos pronto.";
  } else if (tipo === "error") {
    texto = "Hay " + pendientes + (pendientes === 1 ? " campo" : " campos") + " por corregir.";
  } else if (pendientes === 0) {
    texto = "Todo listo, puede enviar el formulario.";
  } else {
    texto = "Complete los campos marcados con *.";
  }

  estadoActual = tipo;
  dibujarEstado(tipo);
  mensajeEstado.textContent = texto;
  mensajeEstado.style.color = colorCSS(tipo === "neutro" ? "--color-texto" : "--color-" + tipo);
  canvasEstado.setAttribute("aria-label", "Estado del formulario: " + texto);
}

// Mientras escribe: si había error y ya se corrigió todo, vuelve a neutro
function refrescarEstado() {
  const hayPendientes = contarValidos() < camposActivos().length;
  actualizarEstado(estadoActual === "error" && hayPendientes ? "error" : "neutro");
}

// ---------- Validación con mensajes en español ----------

// Devuelve el mensaje en español según la propiedad validity del campo
function obtenerMensaje(campo) {
  const v = campo.validity;

  if (v.valueMissing) {
    if (campo.type === "checkbox") return "Debe aceptar que lo contactemos.";
    if (campo.tagName === "SELECT") return "Seleccione un motivo.";
    return "Este campo es obligatorio.";
  }
  if (v.tooShort) return "Escriba al menos " + campo.minLength + " caracteres.";
  if (v.tooLong) return "Escriba como máximo " + campo.maxLength + " caracteres.";
  if (v.typeMismatch) return "Escriba un correo válido, por ejemplo nombre@correo.com.";
  if (v.patternMismatch) return "Use el formato 8888-8888.";
  return "";
}

// Muestra u oculta el error de un campo; devuelve true si es válido
function validarCampo(campo) {
  const error = document.getElementById("error-" + campo.id);
  const mensaje = obtenerMensaje(campo);
  // Un campo opcional vacío no lleva ✓: no hay nada que confirmar
  const tieneValor = campo.type === "checkbox" ? campo.checked : campo.value !== "";

  error.textContent = mensaje;
  campo.classList.toggle("invalido", mensaje !== "");
  campo.classList.toggle("valido", mensaje === "" && tieneValor);
  campo.setAttribute("aria-invalid", mensaje !== "");
  return mensaje === "";
}

// Quita errores y ✓ de un campo
function limpiarCampo(campo) {
  document.getElementById("error-" + campo.id).textContent = "";
  campo.classList.remove("invalido", "valido");
  campo.removeAttribute("aria-invalid");
}

// ---------- Resumen de errores ----------
const resumen = document.getElementById("resumen-errores");
const listaErrores = document.getElementById("lista-errores");

// Arma la lista con un enlace por cada campo con problema
function actualizarResumen() {
  listaErrores.innerHTML = "";

  camposActivos().forEach(function (campo) {
    const mensaje = obtenerMensaje(campo);
    if (mensaje === "") return;

    const nombreCampo = campo.labels[0].textContent.replace("*", "").trim();
    const item = document.createElement("li");
    const enlace = document.createElement("a");
    enlace.href = "#" + campo.id;
    enlace.textContent = nombreCampo + ": " + mensaje;
    // El enlace lleva el foco al campo (no solo hace scroll)
    enlace.addEventListener("click", function (e) {
      e.preventDefault();
      campo.focus();
    });
    item.appendChild(enlace);
    listaErrores.appendChild(item);
  });

  resumen.hidden = listaErrores.children.length === 0;
}

// ---------- Formato automático del teléfono ----------
const telefono = document.getElementById("telefono");

// Deja solo números (máximo 8) y agrega el guion después del cuarto
telefono.addEventListener("input", function () {
  const digitos = telefono.value.replace(/\D/g, "").slice(0, 8);
  telefono.value = digitos.length > 4 ? digitos.slice(0, 4) + "-" + digitos.slice(4) : digitos;
});

// ---------- Dirección: solo si pide visita a domicilio ----------
const motivo = document.getElementById("motivo");
const grupoDireccion = document.getElementById("grupo-direccion");
const direccion = document.getElementById("direccion");

function mostrarDireccion() {
  const visible = motivo.value === "visita";
  grupoDireccion.hidden = !visible;
  // disabled hace que no se valide ni se envíe mientras está oculta
  direccion.disabled = !visible;
  if (!visible) limpiarCampo(direccion);
}

motivo.addEventListener("change", mostrarDireccion);

// ---------- Validar en el momento justo ----------

// Validar al salir del campo; mientras escribe, actualizar si ya se había validado
function validarEnVivo(campo) {
  if (campo.classList.contains("invalido") || campo.classList.contains("valido")) {
    validarCampo(campo);
  }
  if (!resumen.hidden) actualizarResumen();
  refrescarEstado();
}

todosLosCampos.forEach(function (campo) {
  campo.addEventListener("blur", function () {
    validarCampo(campo);
  });
  campo.addEventListener("input", function () {
    validarEnVivo(campo);
  });
  campo.addEventListener("change", function () {
    validarCampo(campo);
    validarEnVivo(campo);
  });
});

// ---------- Envío: "Enviando…" y bloqueo contra envíos dobles ----------
function bloquearBotones(bloquear) {
  botonEnviar.disabled = bloquear;
  botonLimpiar.disabled = bloquear;
  botonEnviar.textContent = bloquear ? "Enviando…" : "Enviar";
  formulario.setAttribute("aria-busy", bloquear);
}

formulario.addEventListener("submit", function (e) {
  e.preventDefault();
  if (enviando) return;

  let primerInvalido = null;
  camposActivos().forEach(function (campo) {
    if (!validarCampo(campo) && !primerInvalido) primerInvalido = campo;
  });

  actualizarResumen();

  if (primerInvalido) {
    actualizarEstado("error");
    primerInvalido.focus();
    return;
  }

  enviando = true;
  bloquearBotones(true);

  // Simulación: aquí iría el envío real al servidor (por ejemplo, con fetch)
  setTimeout(function () {
    formulario.reset();
    // Se espera igual que en "reset" para que la confirmación quede de última
    setTimeout(function () {
      enviando = false;
      bloquearBotones(false);
      actualizarEstado("exito");
    }, 0);
  }, 1500);
});

// ---------- Limpiar con opción de "Deshacer" ----------
const avisoDeshacer = document.getElementById("aviso-deshacer");
const botonDeshacer = document.getElementById("boton-deshacer");
let datosGuardados = null;
let temporizadorAviso = null;

function guardarDatos() {
  datosGuardados = Array.from(todosLosCampos).map(function (campo) {
    return { campo: campo, valor: campo.value, marcado: campo.checked };
  });
  // Si no había nada escrito, no hay nada que deshacer
  return datosGuardados.some(function (dato) {
    return dato.campo.type === "checkbox" ? dato.marcado : dato.valor !== "";
  });
}

function ocultarAviso() {
  avisoDeshacer.hidden = true;
  clearTimeout(temporizadorAviso);
}

formulario.addEventListener("reset", function () {
  // El evento ocurre ANTES de vaciar los campos: es el momento de guardarlos
  const habiaDatos = !enviando && guardarDatos();

  todosLosCampos.forEach(limpiarCampo);
  listaErrores.innerHTML = "";
  resumen.hidden = true;

  // reset() vacía los campos después de este evento, por eso se espera un instante
  setTimeout(function () {
    mostrarDireccion();
    actualizarEstado("neutro");

    if (habiaDatos) {
      avisoDeshacer.hidden = false;
      clearTimeout(temporizadorAviso);
      temporizadorAviso = setTimeout(ocultarAviso, 10000);
    }
  }, 0);
});

botonDeshacer.addEventListener("click", function () {
  datosGuardados.forEach(function (dato) {
    dato.campo.value = dato.valor;
    dato.campo.checked = dato.marcado;
  });
  mostrarDireccion();
  actualizarEstado("neutro");
  ocultarAviso();
  // El botón desaparece: se devuelve el foco al primer campo
  todosLosCampos[0].focus();
});

mostrarDireccion();
actualizarEstado("neutro");
