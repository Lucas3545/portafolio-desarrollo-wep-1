// Paso 3: obtener el canvas y su contexto
const canvas = document.getElementById("mi-logo");
const ctx = canvas.getContext("2d");

// Colores de la marca, tomados de las variables CSS de la página
const estilosPagina = getComputedStyle(document.documentElement);
const colorPrimario = estilosPagina.getPropertyValue("--color-primario").trim();
const colorAcento = estilosPagina.getPropertyValue("--color-acento").trim();
const colorSol = "#f4a259";

// Pasos 4 y 7: fondo con degradado (de arriba hacia abajo)
const degradado = ctx.createLinearGradient(0, 0, 0, 200);
degradado.addColorStop(0, colorPrimario);
degradado.addColorStop(1, colorAcento);
ctx.fillStyle = degradado;
ctx.fillRect(0, 0, 300, 200);

// Paso 8 (reto): rayos del sol repetidos y girados con for
const solX = 150;
const solY = 75;
const totalRayos = 12;

for (let i = 0; i < totalRayos; i++) {
  ctx.save();
  ctx.translate(solX, solY);
  ctx.rotate((i * Math.PI * 2) / totalRayos);
  ctx.fillStyle = colorSol;
  ctx.fillRect(36, -3, 16, 6); // cada rayo empieza fuera del círculo
  ctx.restore();
}

// Paso 5: círculo (el sol)
ctx.beginPath();
ctx.arc(solX, solY, 30, 0, Math.PI * 2);
ctx.fillStyle = colorSol;
ctx.fill();

// Pasos 5 y 7: montaña de atrás, semitransparente con globalAlpha
ctx.globalAlpha = 0.5;
ctx.beginPath();
ctx.moveTo(150, 155);
ctx.lineTo(225, 85);
ctx.lineTo(300, 155);
ctx.closePath();
ctx.fillStyle = "#ffffff";
ctx.fill();
ctx.globalAlpha = 1; // se regresa a 1 para que lo demás salga opaco

// Paso 5: triángulo (montaña del frente)
ctx.beginPath();
ctx.moveTo(20, 155);
ctx.lineTo(120, 70);
ctx.lineTo(220, 155);
ctx.closePath();
ctx.fillStyle = colorPrimario;
ctx.fill();

// Franja inferior para que el texto se lea bien
ctx.fillStyle = colorPrimario;
ctx.fillRect(0, 155, 300, 45);

// Pasos 6 y 7: nombre del negocio con sombra (aislada con save y restore)
ctx.save();
ctx.shadowColor = "rgba(0, 0, 0, 0.5)";
ctx.shadowBlur = 4;
ctx.shadowOffsetX = 2;
ctx.shadowOffsetY = 2;
ctx.fillStyle = "#ffffff";
ctx.font = "bold 32px Georgia, serif";
ctx.textAlign = "center";
ctx.fillText("Camvas", 150, 190);
ctx.restore();
