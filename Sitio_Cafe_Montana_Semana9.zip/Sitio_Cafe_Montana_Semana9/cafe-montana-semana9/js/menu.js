/* ==========================================================
   menu.js · Logotipo en canvas y botón del menú en celular
   ========================================================== */

// Logotipo (64 x 64) dibujado con canvas
(function () {
  const canvas = document.getElementById("logo");
  if (!canvas) return;
  const dpr = window.devicePixelRatio || 1;
  canvas.width = 64 * dpr; canvas.height = 64 * dpr;
  canvas.style.width = "48px"; canvas.style.height = "48px";
  const ctx = canvas.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.fillStyle = "#4B2E1E"; ctx.beginPath(); ctx.arc(32, 32, 31, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = "#2F6B4F"; ctx.beginPath();
  ctx.moveTo(6, 50); ctx.lineTo(24, 20); ctx.lineTo(34, 36); ctx.lineTo(42, 26); ctx.lineTo(58, 50); ctx.closePath(); ctx.fill();
  ctx.fillStyle = "#F6EBDD"; ctx.beginPath();
  ctx.moveTo(18, 34); ctx.lineTo(44, 34); ctx.lineTo(41, 50); ctx.quadraticCurveTo(40, 53, 37, 53);
  ctx.lineTo(25, 53); ctx.quadraticCurveTo(22, 53, 21, 50); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = "#F6EBDD"; ctx.lineWidth = 3.5;
  ctx.beginPath(); ctx.arc(46, 41, 6, -Math.PI / 2, Math.PI / 2); ctx.stroke();
})();

// Botón «Menú» (solo se ve en pantallas angostas)
(function () {
  const boton = document.querySelector(".menu-toggle");
  const menu = document.getElementById("menu-principal");
  if (!boton || !menu) return;
  boton.addEventListener("click", () => {
    const abierto = menu.classList.toggle("abierto");
    boton.setAttribute("aria-expanded", abierto ? "true" : "false"); // avisa a lectores de pantalla
  });
  // Con la tecla Escape se cierra el menú
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && menu.classList.contains("abierto")) {
      menu.classList.remove("abierto");
      boton.setAttribute("aria-expanded", "false");
      boton.focus();
    }
  });
})();
