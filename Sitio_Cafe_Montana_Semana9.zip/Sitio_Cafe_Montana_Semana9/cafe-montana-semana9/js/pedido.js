/* ==========================================================
   pedido.js · Arrastrar y soltar (Drag & Drop) con la API de HTML
   Eventos: dragstart (empieza) → dragover (pasa por encima)
            → drop (se suelta) → dragend (termina)
   Siempre hay una alternativa sin arrastrar: el botón «Agregar».
   ========================================================== */
const productos = document.querySelectorAll("#productos .producto");
const zona = document.getElementById("bolsa");
const lista = document.getElementById("elegidos");
const vacio = document.getElementById("vacio");
const totalEl = document.getElementById("total");
const bolsa = []; // { id, nombre, precio }

const dinero = new Intl.NumberFormat("es-CR", { style: "currency", currency: "CRC", maximumFractionDigits: 0 });

// 1) Cada producto se puede arrastrar: guardamos su id en dataTransfer
productos.forEach((p) => {
  p.addEventListener("dragstart", (e) => {
    e.dataTransfer.setData("text/plain", p.dataset.id);
    e.dataTransfer.effectAllowed = "copy";
    p.classList.add("arrastrando");
  });
  p.addEventListener("dragend", () => p.classList.remove("arrastrando"));
  // Alternativa para teclado y celular
  p.querySelector("button").addEventListener("click", () => agregar(p.dataset.id));
});

// 2) La zona acepta lo que se suelte encima
zona.addEventListener("dragover", (e) => {
  e.preventDefault();                 // sin esto, el navegador NO permite soltar
  zona.classList.add("sobre");
});
zona.addEventListener("dragleave", () => zona.classList.remove("sobre"));
zona.addEventListener("drop", (e) => {
  e.preventDefault();
  zona.classList.remove("sobre");
  agregar(e.dataTransfer.getData("text/plain"));
});

// 3) Agregar, quitar y mostrar
function agregar(id) {
  const p = document.querySelector('#productos [data-id="' + id + '"]');
  if (!p) return;
  bolsa.push({ id, nombre: p.dataset.nombre, precio: Number(p.dataset.precio) });
  mostrar();
}
function quitar(indice) {
  bolsa.splice(indice, 1);
  mostrar();
}
function mostrar() {
  lista.innerHTML = "";
  bolsa.forEach((item, i) => {
    const li = document.createElement("li");
    li.className = "producto";
    li.style.cursor = "default";
    li.innerHTML = "<span></span><span class=\"precio\"></span><button type=\"button\" class=\"btn btn-sm btn-outline-danger\">Quitar</button>";
    li.children[0].textContent = item.nombre;
    li.children[1].textContent = dinero.format(item.precio);
    li.querySelector("button").addEventListener("click", () => quitar(i));
    lista.appendChild(li);
  });
  vacio.hidden = bolsa.length > 0;
  totalEl.textContent = dinero.format(bolsa.reduce((s, x) => s + x.precio, 0));
}
document.getElementById("vaciar").addEventListener("click", () => { bolsa.length = 0; mostrar(); });
mostrar();
