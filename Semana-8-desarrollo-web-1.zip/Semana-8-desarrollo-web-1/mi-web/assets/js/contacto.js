const form = document.getElementById("formContacto");
const resumen = document.getElementById("resumenErrores");
const estado = document.getElementById("estadoEnvio");
const btnEnviar = document.getElementById("btnEnviar");

const campos = form.querySelectorAll("input, select, textarea");

function mensajeDe(campo) {
    const v = campo.validity;

    if (v.valueMissing) {
        if (campo.name === "nombre") return "Escribe tu nombre completo.";
        if (campo.name === "correo") return "Escribe tu correo, por ejemplo nombre@dominio.cl.";
        if (campo.name === "motivo") return "Selecciona el motivo de tu mensaje.";
        if (campo.name === "mensaje") return "Escribe tu mensaje.";
        if (campo.type === "checkbox") return "Debes aceptar el tratamiento de datos para que podamos contactarte.";
        return "Este campo es obligatorio.";
    }
    if (v.typeMismatch) return "Ingresa un correo válido, por ejemplo correo@ejemplo.com.";
    if (v.tooShort) {
        if (campo.name === "nombre") return `El nombre debe tener al menos ${campo.minLength} letras.`;
        return `Debe tener al menos ${campo.minLength} caracteres (tienes ${campo.value.length}).`;
    }
    if (v.tooLong) return `Debe tener como máximo ${campo.maxLength} caracteres.`;
    if (v.patternMismatch) {
        if (campo.name === "nombre") return "Usa solo letras y espacios.";
        if (campo.name === "correo") return "Ingresa un correo válido, por ejemplo nombre@dominio.cl.";
        if (campo.name === "telefono") return "Usa 8 dígitos, con o sin guion. Ejemplo: 8888-8888.";
        return "El formato no es válido.";
    }
    return "";
}

// Valida un campo, muestra u oculta su error y devuelve true si es válido
function validarCampo(campo) {
    const error = document.getElementById(`${campo.id}-error`);
    const mensaje = campo.validity.valid ? "" : mensajeDe(campo);

    // Ícono además del color; "Error:" queda solo para lectores de pantalla
    error.innerHTML = mensaje
        ? `<span class="icono-error" aria-hidden="true">⚠</span><span class="visually-hidden">Error: </span>${mensaje}`
        : "";
    campo.setAttribute("aria-invalid", mensaje ? "true" : "false");

    return !mensaje;
}

// Contador de caracteres del mensaje
const mensaje = document.getElementById("mensaje");
const contador = document.getElementById("mensaje-contador");

function actualizarContador() {
    contador.textContent = `${mensaje.value.length} / ${mensaje.maxLength}`;
}

mensaje.addEventListener("input", actualizarContador);

// Validar al salir del campo y corregir en vivo una vez marcado
campos.forEach(campo => {
    campo.addEventListener("blur", () => validarCampo(campo));
    campo.addEventListener("input", () => {
        if (campo.getAttribute("aria-invalid") === "true") validarCampo(campo);
    });
    campo.addEventListener("change", () => validarCampo(campo));
});

form.addEventListener("submit", (e) => {
    e.preventDefault();
    estado.textContent = "";

    const invalidos = [...campos].filter(campo => !validarCampo(campo));

    if (invalidos.length > 0) {
        const items = invalidos
            .map(campo => `<li><a href="#${campo.id}">${mensajeDe(campo)}</a></li>`)
            .join("");

        resumen.innerHTML = `<p><strong>Revisa estos ${invalidos.length} campo(s) antes de enviar:</strong></p><ul>${items}</ul>`;
        resumen.hidden = false;
        invalidos[0].focus();
        return;
    }

    resumen.hidden = true;
    resumen.innerHTML = "";

    const datos = new FormData(form);
    const nombre = datos.get("nombre").trim();

    btnEnviar.disabled = true;
    btnEnviar.textContent = "Enviando…";
    estado.className = "estado-envio enviando";
    estado.textContent = "Enviando…";

    // Simulación del envío al servidor
    setTimeout(() => {
        console.log("Datos enviados:", Object.fromEntries(datos));

        estado.className = "estado-envio exito";
        estado.textContent = `¡Gracias, ${nombre}! Tu mensaje fue enviado correctamente.`;

        form.reset();
        actualizarContador();
        campos.forEach(campo => campo.removeAttribute("aria-invalid"));
        btnEnviar.disabled = false;
        btnEnviar.textContent = "Enviar mensaje";
    }, 1500);
});

// Al hacer clic en un enlace del resumen, llevar el foco al campo
resumen.addEventListener("click", (e) => {
    const enlace = e.target.closest("a");
    if (!enlace) return;
    e.preventDefault();
    document.querySelector(enlace.getAttribute("href")).focus();
});
